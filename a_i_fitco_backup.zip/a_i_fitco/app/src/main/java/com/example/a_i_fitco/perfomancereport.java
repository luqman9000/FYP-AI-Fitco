package com.example.a_i_fitco;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import nl.dionsegijn.konfetti.core.Angle;
import nl.dionsegijn.konfetti.core.PartyFactory;
import nl.dionsegijn.konfetti.core.Position;

import nl.dionsegijn.konfetti.core.Spread;
import nl.dionsegijn.konfetti.core.emitter.Emitter;
import nl.dionsegijn.konfetti.core.emitter.EmitterConfig;
import nl.dionsegijn.konfetti.xml.KonfettiView;

public class perfomancereport extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfomancereport);
        TextView durasi = findViewById(R.id.textView10);
        TextView kalori = findViewById(R.id.textView12);

        long getDifference = stopwatcher.getDifference();
        long getDifferencew1 = stopwatcher.getDifferencew1();
        long getDifferencew2 = stopwatcher.getDifferencew2();

        long getMinute = (getDifference/1000)/60;
        long getMinutew1 = (getDifferencew1/1000)/60;
        long getMinutew2 = (getDifferencew2/1000)/60;
        long getSecond = (int)((getDifference / 1000) % 60);

        double getWeight = BMIActivity.getWeight();
        double pushupMET = 8*3.5;
        double squatMET = 5.5*3.5;
        double calories = (getMinutew1+getMinutew2)*(pushupMET+squatMET)*(getWeight/200);


        String s=String.valueOf(getMinute);
        String m=String.valueOf(getSecond);
        String e=String.valueOf(calories);

        Log.d("Workout 1 duration = ", String.valueOf(getMinutew1));
        Log.d("Workout 2 duration = ", String.valueOf(getMinutew2));
        Log.d("Weight = ", String.valueOf(getWeight));
        Log.d("squatMET = ", String.valueOf(squatMET));
        Log.d("pushupMET = ", String.valueOf(pushupMET));
        Log.d("Kalori = ", String.valueOf(calories));


        durasi.setText(s+" minutes "+m+" seconds");
        kalori.setText(e+" kcal ");


    }
}