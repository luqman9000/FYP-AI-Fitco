package com.example.a_i_fitco;

import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;
import com.google.common.base.Stopwatch;
import static xdroid.toaster.Toaster.toast;
import static xdroid.toaster.Toaster.toastLong;




public class stopwatcher {
    private static long startTime = 0;
    private static long startTimew2 = 0;
    //overall workout duration
    private static long difference;
    public static long getDifference(){

        return difference;
    }

    //workout 1 duration
    private static long differencew1;
    public static long getDifferencew1(){

        return differencew1;
    }

    //workout 2 duration
    private static long differencew2;
    public static long getDifferencew2(){

        return differencew2;
    }

    public static void swstart(){
        startTime = SystemClock.elapsedRealtime();
    }

    public static void swstop(){
        difference = SystemClock.elapsedRealtime() - startTime;
        Log.d("Saari Bukit Sagu = ", String.valueOf(difference));

    }

    public static void swstopw1(){
        differencew1 = SystemClock.elapsedRealtime() - startTime;
        Log.d("workout duration 1 = ", String.valueOf(difference));
        //start recording duration for workout 2

    }

    public static void swstart2(){
        startTimew2 = SystemClock.elapsedRealtime();
    }

    public static void swstopw2(){
        differencew2 = SystemClock.elapsedRealtime() - startTimew2;
        Log.d("workout duration 1 = ", String.valueOf(differencew2));
    }
}
